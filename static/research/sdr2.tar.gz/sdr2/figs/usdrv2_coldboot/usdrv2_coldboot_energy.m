clear all; close all;

data = csvread('usdrv2_coldboot.csv', 17);
time = data(:,1);
dc_input = data(:,2);
system_ready = data(:,6);
gain = 11.64;	% V/I = G, I = V/G
current = data(:,4)/gain;
sampling_period = time(2) - time(1);

clear data;
window_size = 10;

current = medfilt1(current, window_size);
dc_input = medfilt1(dc_input, window_size);
system_ready = medfilt1(system_ready, window_size);

data = [time, dc_input, system_ready, current];
save ('usdrv2_coldboot.txt', 'data', '-ascii');

time_start = -4e-5;	% observe from graph
time_stop = 0.05352; % observe from graph

[diff, start_idx] = min(abs(time - time_start));
[diff, stop_idx] = min(abs(time - time_stop));

cold_boot_energy = 0;
for i=start_idx:stop_idx
	cold_boot_energy = cold_boot_energy + dc_input(i)*current(i) * sampling_period; % unit: Joule
end
