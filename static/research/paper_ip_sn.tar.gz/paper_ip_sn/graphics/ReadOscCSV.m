function [t,x] = ReadOscCSV(filename)
%READOSCCSV 
    d = dlmread(filename,',');
    t = d(:,1); %time
    x = d(:,2); %voltage
end

