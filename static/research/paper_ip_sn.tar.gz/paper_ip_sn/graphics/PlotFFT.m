function PlotFFT(t, x, ttl, x_last, y_last, savename) 
%PlotFFT
%Input: Time, signal, title, x-limit, y-limit, "filename.png"

	% Calculate sample rate and freq bin size
	npts = length(x);
	sr = npts / (t(end) - t(3));
	f_bin = sr / npts;
	f = 0:f_bin:sr;
	f = f(1:npts/2);
	
	% Apply Hann Window to points
	wh = hanning(npts);
	fx = fft( x .* wh );
	
	% Scale points to real world units
	%sfx = fx .* fx;
	%scfx = sqrt(sfx ./ npts);
	scfx = abs(fx);
	scfx = scfx(1:npts/2);
	scfx = scfx .* 2 * sqrt(2);
	
	% Remove scaling from first and end points
	scfx(1) = scfx(1) / 2 / sqrt(2);
	scfx(end) = scfx(end) / 2 / sqrt(2);
	
	% Plot FFT
	%plot(f, abs(scfx(1:npts/2)))
	%dlmwrite('/tmp/dlmf', f.', ',')
	%dlmwrite('/tmp/dlms', abs(scfx(1:npts/2)), ' ')
	M = [f.', abs(scfx(1:npts/2))]
	dlmwrite(savename, M, '\t')
	%axis([0, x_last, 0, y_last]);
	%title(ttl);
	%xlabel('Frequency (Hz)');
	%ylabel('Amplitude (mV)');
	
	% Optional: Save as png
	%if nargin == 6
	%	print(savename);
	%	replot;
	%end
end

