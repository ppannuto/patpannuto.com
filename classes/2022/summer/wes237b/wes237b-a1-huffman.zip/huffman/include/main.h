#ifndef main_h
#define main_h

#include <iostream>
#include <stdlib.h>


#endif /* main_h */
